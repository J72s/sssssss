const fs = require('fs');
const path = require('path');
const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;
const categories = require("../categories.json").categories;

// Load alphabet
const alphabet = "أبتثجحخدذرزسشصضطظعغفقكلمنهوي";

/**
 * @description عكس الرقم
 * @param {Discord.Client} client العميل الذي يشغل الأوامر
 * @param {Discord.Message} message رسالة الأمر
 * @param {Array<String>} args الحجج الممررة مع الأمر
 */
module.exports.run = async (client, message, args) => {
    try {
        let roundCount = parseInt(args[0], 10) || 1; // عدد الجولات المحددة من قبل المستخدم أو افتراضياً 1
        if (isNaN(roundCount) || roundCount <= 0) {
            message.channel.send("يرجى تحديد عدد صحيح من الجولات.");
            return;
        }

        let currentRoundIndex = 0;
        let scores = {};

        message.channel.send(strings.eventStart5);

        const reverseNumber = (number) => {
            const reversed = parseInt(number.toString().split('').reverse().join(''));
            return Math.max(1, Math.min(reversed, 99)); // Ensure the reversed number is between 1 and 99
        };

        const askQuestion = async () => {
            const randomNumber = Math.floor(Math.random() * 99) + 1; // Random number between 1 and 99
            const oppositeNumber = reverseNumber(randomNumber); // Reverse the digits

            const questionMessage = await message.channel.send(strings.questionPrompt5.replace("{number}", randomNumber));

            const filter = response => {
                const numbers = response.content.split(' ');
                if (numbers.length !== 1) return false;
                return parseInt(numbers[0]) === oppositeNumber; // Check if user input is the opposite of the random number
            };

            const collector = message.channel.createMessageCollector({ filter, time: 15000 });

            collector.on('collect', (response) => {
                const user = response.author.tag;
                if (!scores[user]) scores[user] = 0;

                scores[user] += 1; // Each correct answer gets one point

                response.channel.send(strings.correctAnswer.replace("{user}", response.author).replace("{points}", 1));
                collector.stop('answered');
            });

            collector.on('end', (collected, reason) => {
                if (reason === 'time') {
                    message.channel.send(strings.timeUp);
                }

                currentRoundIndex++;

                if (currentRoundIndex < roundCount) {
                    askQuestion(); // Ask the next question
                } else {
                    // End of the game
                    let highestScore = 0;
                    let winners = [];
                    Object.entries(scores).forEach(([user, points]) => {
                        if (points > highestScore) {
                            highestScore = points;
                            winners = [user];
                        } else if (points === highestScore) {
                            winners.push(user);
                        }
                    });

                    let scoreMessage = "**انتهت اللعبة! إليكم النقاط النهائية:**\n";
                    const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);

                    sortedScores.forEach(([user, points]) => {
                        scoreMessage += `${user}: ${points} نقاط\n`;
                    });

                    if (sortedScores.length === 0) {
                        scoreMessage += "لم يجيب أحد بشكل صحيح.";
                    }

                    message.channel.send(scoreMessage);
                }
            });
        };

        askQuestion();

    } catch (error) {
        // Log the error
        console.error("حدث خطأ أثناء اللعبة:", error);
        message.channel.send(strings.errorStartingGame);
    }
};

module.exports.names = {
    list: ["عكس", "رقم"]
};
