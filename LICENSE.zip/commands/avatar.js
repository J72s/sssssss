const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Change the bot's activity status
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    // Check if the message is sent in a guild
    if (!message.guild) {
        return message.channel.send(strings.notInGuild);
    }

    // Check if the message author is allowed to change the activity statusreturn message.channel.send(strings.noPermission);
    if (!allowedUsers.includes(message.author.id)) { // Fix the check for allowed users
        return;
    }

    try {
        // Fetch the attachment (avatar) sent with the command
        const attachment = message.attachments.first();
        if (!attachment) {
            return message.channel.send(strings.noAttachment);
        }

        // Set the bot's avatar to the attached image
        await client.user.setAvatar(attachment.url);

        // Send a confirmation message
        message.channel.send(strings.avatarChanged);
    } catch (error) {
        // Log the error
        console.error("Error occurred while changing avatar:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while changing avatar:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorChangingAvatar);
    }
};

module.exports.names = {
    list: ["ava", "avatar", "تغييرالصورة"]
};
