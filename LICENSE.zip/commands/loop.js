const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Loop the current song
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args useless here  
 */
module.exports.run = async (client, message, args) => {
    try {
        const serverQueue = queue.get("queue");

        if (!serverQueue) {
            return message.channel.send(strings.cantLoop);
        }

        if (serverQueue.loop === false) {
            serverQueue.loop = true;
            client.channels.cache.get('1240050863007862815').send(`Started looping : ${serverQueue.songs[0].title}`);
            message.channel.send(strings.loopOn.replace("SONG_TITLE", serverQueue.songs[0].title));
        } else {
            serverQueue.loop = false;
            client.channels.cache.get('1240050863007862815').send(`Stopped looping : ${serverQueue.songs[0].title}`);
            message.channel.send(strings.loopOff.replace("SONG_TITLE", serverQueue.songs[0].title));
        }
    } catch (error) {
        // Log the error
        console.error("Error occurred while looping song:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while looping song:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorLoop);
    }
};

module.exports.names = {
    list: ["loop", "l", "تكرار"]
};
